# Day2日报by朱梦圆

## 1 第3章 图形初阶

本章讨论处理图形的一般方法：

- 创建和保存图形
- 修改图形的标题、坐标轴、标签、颜色、线条、符号和 文本标注
- 究组合多幅图形为单幅图形

### 1.1 使用图形

- 构建图形：``通过逐条输入语句构建图形，逐渐完善图形特征``

  示例：

  ```R
  attach(mtcars) #绑定数据框mtcars
  plot(wt,mpg) #生成散点图，横轴车重，纵轴每加仑汽油行驶的英里数
  abline(lm(mpg~wt)) #添加最优拟合曲线
  title("Regression of MPG on Weight") #添加标题
  detach(mtcars) #解除数据框绑定
  ```

  逐条运行代码结果如下：

  - 创建散点图

    ![](1.1散点图.JPG)

  - 添加拟合线

    ![](1.1添加拟合线.JPG)

  - 添加标题

    ![](1.1添加标题.JPG)

- 保存图形：``通过代码或图形用户界面来保存图形``

  - **通过代码保存图形示例：**

  ```R
  pdf("mygraph.pdf") #将图形保存到名为mygraph.pdf的pdf文件中
  attach(mtcars) #绑定数据框mtcars
  plot(wt,mpg) #生成散点图，横轴车重，纵轴每加仑汽油行驶的英里数
  abline(lm(mpg~wt)) #添加最优拟合曲线
  title("Regression of MPG on Weight") #添加标题
  detach(mtcars) #解除数据框绑定
  dev.off()
  ```

  除了==pdf()==，还可以使用函数==win.metafile()，png()，jpeg()，bmp()，tiff()，xfig() 和postscript()==将图形保存为其他格式。

  - **通过图形用户界面保存图形示例：**

  对于Windows，在图形窗口中选择“文件”→ “另存为“，在弹出的对话框中选择想要的格式和保存位置即可。

- 创建多个图形并查看

  - 方法1：**在创建一幅新图形之前打开一个新的图形窗口**

    ```R
    dev.new() 
     statements to create graph 1
    dev.new() 
     statements to create a graph 2 
    ```

  - 方法2：**通过图形用户界面来查看多个图形**

    在Windows上，在打开第一个图形窗口以后，勾选“历史”（History）→“记录”（Recording）。然后使用菜单中的“上一个”（Previous）和“下一个”（Next）来逐个查看已经绘制的图形。 

  - 方法3：**使用函数dev.new()，dev.next()，dev.prev()，dev.set()和 dev.off()同时打开多个图形窗口**

### 1.2 一个简单的例子

``利用假想数据集创建图形``

代码如下：

```R
dose<-c(20,30,40,45,60)
drugA<-c(16,20,27,40,60)
drugB<-c(15,18,25,31,40)
plot(dose,drugA,type="b") #横轴dose，纵轴drugA，type="b"表示同时绘制点和线
```

结果如下：

![](1.2创建假想数据集结果.JPG)

### 1.3 图形参数

方法一：==通过函数par()来指定图形参数选项==

- 用par()设定的参数值除非被再次修改，否则将在会话结束前一直有效
- 调用格式：par(*optionname=value*,  optionname=name,...)
- 不加参数地执行par()将生成一个含有当前图形参数设置的列表
- 添加参数no.readonly=TRUE可以生成一个可以修改的当前图形参数列表

示例：

代码如下：

```R
opar<-par(no.readonly=TRUE) #复制当前图形参数设置
par(lty=2,pch=17) #将默认的线条类型修改为虚线，将默认的点符号改为实心三角
plot(dose,drugA,type="b")
par(opar)
```

结果如下：

![](1.3修改图片参数.JPG)

方法二：==为高级绘图函数直接提供*optionname=value*的键值对==

代码如下：

```R
plot(dose,drugA,type="b",lty=2,pch=17)
```

#### 1.3.1 符号和线条

- ==用于指定符号和线条类型的参数==

  ![](1.3.1用于指定符号和线条类型的参数.JPG)

  示例：

  代码如下：

  ```R
  plot(dose, drugA, type="b", lty=3, lwd=3, pch=15, cex=2)
  ```

  结果如下：

  ![](1.3.1改变图片符号和线条.JPG)

#### 1.3.2 颜色

- ==用于指定颜色的参数==

  ![](1.3.2用于指定颜色的参数.JPG)

- 在R中，可以通过==颜色下标、颜色名称、十六进制的颜色值、RGB值或HSV值==来指定颜色

  - rgb()：可基于红-绿-蓝三色值生成颜色

  - hsv()：基于色相-饱和度-亮度值来生成颜色

  - colors()：可以返回所有可用颜色的名称

  - 创建连续型颜色向量的函数：rainbow()、heat.colors()、terrain.colors()、topo.colors() 以及cm.colors()

  - 颜色配对：RColorBrewer

  - gray()：生成多阶灰度色

    gray(0:10/10)将生成10阶灰度色

- 示例：

  代码如下：

  ```R
  n <- 10 
  mycolors <- rainbow(n) 
  pie(rep(1, n), labels=mycolors, col=mycolors) #创建彩色饼图
  mygrays <- gray(0:n/n) 
  pie(rep(1, n), labels=mygrays, col=mygrays) #创建灰度色饼图
  ```

  结果如图：

  ![](1.3.2示例1.JPG)

  ![](1.3.2示例2-1572610212178.JPG)

#### 1.3.3 文本属性

- ==用于指定文本大小的参数==

  ![](1.3.3指定文本大小的参数.JPG)

- ==用于指定字体族、字号和字样的参数==

  ![](1.3.3指定字体族、字号和字样的参数.JPG)

- 字体族的设置

  - 在Windows中，可以通过函数windowsFont()来创建字体映射
  - 以PDF形式输出图形修改字体族：
    - 第一步：用names(pdfFonts())找出系统中的可用字体
    - 第二步：用pdf(file= "*myplot.pdf*", family="*fontname*")生成图形

  - 以PostScript形式输出图形修改字体族：
    - 第一步：用names(postscriptFonts())找出系统中的可用字体
    - 第二步：用postscript(file="*myplot.ps*", family= "*fontname*")生成图形

#### 1.3.4 图形尺寸与边界尺寸

- ==用于控制图形尺寸和边界大小的参数==

  ![](1.3.4用于控制图形尺寸和边界大小的参数.JPG)

- 示例：

  ```R
  dose <- c(20, 30, 40, 45, 60) 
  drugA <- c(16, 20, 27, 40, 60) 
  drugB <- c(15, 18, 25, 31, 40) 
  opar <- par(no.readonly=TRUE) 
  par(pin=c(2, 3))  #2英寸宽，3英寸高
  par(lwd=2, cex=1.5)  #线宽为默认的2倍，符号为默认的1.5倍
  par(cex.axis=.75, font.axis=3)  #坐标轴刻度文本缩小为默认的0.75倍，设置为斜体
  plot(dose, drugA, type="b", pch=19, lty=2, col="red")  #采用红色实心圆、虚线绘图
  plot(dose, drugB, type="b", pch=23, lty=6, col="blue", bg="green")  #使用绿色填充的绿色菱形加蓝色边框和蓝色虚线
  par(opar) #还原初始图形参数设置
  ```

结果如下：

![](1.3.4示例1.JPG)

![](1.3.4示例2.JPG)

### 1.4 添加文本、自定义坐标轴和图例

#### 1.4.1 标题

- 使用==title()==函数为图形添加标题和坐标轴标签

  函数title()一般来说被用于添加信息到一个**默认标题和坐标轴标签被ann=FALSE选项移除的图形**中

#### 1.4.2 坐标轴

- 使用函数==axis()==来创建自定义的坐标轴

  - 创建自定义坐标轴时，应当禁用高级绘图函数自动生成的坐标轴

  - 创建格式：axis(*side*, at=, labels=, pos=, lty=, col=, las=, tck=, ...)

    ![](1.4.2坐标轴选项1.JPG)

    ![](1.4.2坐标轴选项2.JPG)

- lines()：为一幅现有图形添加新的图形元素
- mtext()：用于在图形的边界添加文本
- minor.tick()：添加次要刻度线

#### 1.4.3 参考线

- abline()：添加参考线

  - 格式：abline(h=*yvalues*, v=*xvalues*) 

    ```R
    abline(h=c(1,5,7)) #y为1、5、7的位置添加了水平实线
    abline(v=seq(1, 10, 2), lty=2, col="blue") #在x为1、3、5、7、9的位置添加了垂直的蓝色虚线
    ```

#### 1.4.4 图例

- legend()：添加图例

  - 格式：legend(*location*, *title*, *legend*, ...) 
  - 图例选项：

  ![](1.4.4图例选项.JPG)

  - 其他选项：
    - bty：指定盒子样式
    - bg：指定背景色
    - cex：指定大小
    - text.col：指定文本颜色
    - horiz=TRUE：水平放置图例

- 示例：

  ```R
  dose <- c(20, 30, 40, 45, 60) 
  drugA <- c(16, 20, 27, 40, 60) 
  drugB <- c(15, 18, 25, 31, 40) 
  opar <- par(no.readonly=TRUE) 
  par(lwd=2, cex=1.5, font.lab=2)
  plot(dose, drugA, type="b", pch=15, lty=1, col="red", ylim=c(0, 60), main="Drug A vs. Drug B", xlab="Drug Dosage", ylab="Drug Response")
  lines(dose, drugB, type="b", pch=17, lty=2, col="blue") 
  abline(h=c(30), lwd=1.5, lty=2, col="gray") 
  library(Hmisc) 
  minor.tick(nx=3, ny=3, tick.ratio=0.5)
  legend("topleft", inset=.05, title="Drug Type", c("A","B"), lty=c(1, 2), pch=c(15, 17), col=c("red", "blue"))
  par(opar)
  ```

  ![](1.4.4示例.JPG)

#### 1.4.5 文本标注

- text()或mtext()：添加文本
  - text()：向绘图区域内部添加文本
    - 格式：text(*location*, "*text to place*", *pos*, ...) 
    - text()函数也通常用来标示图形中的点
  - mtext()：向图形的四个边界之一添加文本
    - 格式：mtext("*text to place*", *side*, line=*n*, ...) 
- 其他常用选项
  - cex：调整字号
  - col：调整颜色
  - font：调整字体样式

#### 1.4.6 数学标注

- plotmath()：可以为图形主体或边界上的==标题、坐标轴名称或文本标注==添加数学符号

### 1.5 图形的组合

- par()或layout()：组合多幅图形为一幅总括图形
  - 为控制每幅图形的大小，可以在layout()函数中使用widths=和heights=两个参数
    - widths = 各列宽度值组成的一个向量
    - heights = 各行高度值组成的一个向量

### 1.6 小结

- 回顾创建图形和保存图形的方法
- 学习修改一幅图形的坐标轴、字体、绘图符号、线条和颜色
- 学习如何添加标题、副标题、标签、文本、图例和参考线

## 2 自定义绘图

- 代码如下：

  ```R
  attach(mtcars) 
  opar <- par(no.readonly=TRUE) 
  par(mfrow=c(2,2))
  plot(wt,mpg, main="Scatterplot of wt vs. mpg",col.main="green", pch=23, lty=6, col="blue", bg="green") 
  plot(wt,disp, main="Scatterplot of wt vs. disp",col.main="red", pch=19, lty=2, col="red") 
  hist(wt, main="Histogram of wt",col.main="blue", lty=2, col="blue") 
  boxplot(wt, main="Boxplot of wt",col.main="orange",lty=2, col="orange") 
  par(opar) 
  detach(mtcars)
  ```

- 结果如下：

  ![](自定义丑图.JPG)